package com.cosmicclient.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.graphics.Color;
import android.view.Window;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Comparator;

public class MainActivity extends Activity {
    private static final int REQUEST_PICK_MCPACK = 4207;
    private static final long MAX_PACK_BYTES = 100L * 1024L * 1024L;
    private WebView webView;
    private File packsDir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(8, 6, 15));
        window.setNavigationBarColor(Color.rgb(8, 6, 15));
        window.getDecorView().setSystemUiVisibility(0);
        packsDir = new File(getFilesDir(), "texture-packs");
        if (!packsDir.exists()) packsDir.mkdirs();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 6, 15));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new CosmicBridge(), "CosmicAndroid");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/web/index.html");
    }

    private void jsStatus(String message, boolean error) {
        if (webView == null) return;
        try {
            JSONObject value = new JSONObject();
            value.put("message", message);
            value.put("error", error);
            String json = value.toString();
            webView.post(() -> webView.evaluateJavascript(
                "window.packManager&&window.packManager.onPackStatus(" + JSONObject.quote(message) + "," + error + ")", null));
        } catch (Exception ignored) { }
    }

    private void sendPackList() {
        if (webView == null) return;
        JSONArray list = new JSONArray();
        File[] files = packsDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".mcpack"));
        if (files == null) files = new File[0];
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        for (File file : files) {
            try {
                JSONObject item = new JSONObject();
                item.put("name", file.getName());
                item.put("sizeLabel", readableSize(file.length()) + " • Minecraft Bedrock pack");
                list.put(item);
            } catch (Exception ignored) { }
        }
        String json = list.toString();
        webView.post(() -> webView.evaluateJavascript(
            "window.packManager&&window.packManager.onPacksChanged(" + JSONObject.quote(json) + ")", null));
    }

    private String readableSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return new DecimalFormat("0.0").format(bytes / 1024.0) + " KB";
        return new DecimalFormat("0.0").format(bytes / (1024.0 * 1024.0)) + " MB";
    }

    private String displayName(Uri uri) {
        String name = null;
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) name = cursor.getString(index);
            }
        } catch (Exception ignored) { }
        if (name == null || name.trim().isEmpty()) name = "texture-pack.mcpack";
        return new File(name).getName().replaceAll("[^A-Za-z0-9._ -]", "_");
    }

    private void importPack(Uri uri) {
        String name = displayName(uri);
        if (!name.toLowerCase().endsWith(".mcpack")) {
            jsStatus("That file does not end in .mcpack. Please choose a Minecraft Bedrock pack file.", true);
            return;
        }
        File destination = new File(packsDir, name);
        String base = name.substring(0, name.length() - ".mcpack".length());
        int suffix = 2;
        while (destination.exists()) destination = new File(packsDir, base + " (" + suffix++ + ").mcpack");
        long total = 0;
        try (InputStream in = getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(destination)) {
            if (in == null) throw new Exception("Android could not read that file.");
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) {
                total += count;
                if (total > MAX_PACK_BYTES) {
                    out.close();
                    destination.delete();
                    jsStatus("Pack is larger than 100 MB. Choose a smaller .mcpack file.", true);
                    return;
                }
                out.write(buffer, 0, count);
            }
            out.flush();
            jsStatus("Imported " + destination.getName() + " into the Cosmic library.", false);
            sendPackList();
        } catch (Exception e) {
            destination.delete();
            jsStatus("Import failed. Check that the file is available and try again.", true);
        }
    }

    private void openPack(String name) {
        if (name == null || name.contains("/") || name.contains("\\") || !name.toLowerCase().endsWith(".mcpack")) {
            jsStatus("Invalid pack name.", true); return;
        }
        File file = new File(packsDir, name);
        if (!file.isFile()) { jsStatus("Pack not found in the Cosmic library.", true); sendPackList(); return; }
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
        Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(uri, "application/octet-stream");
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            if (view.resolveActivity(getPackageManager()) != null) {
                startActivity(Intent.createChooser(view, "Open .mcpack with"));
                jsStatus("Choose Minecraft if it appears in the Android app chooser.", false);
            } else {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("application/octet-stream");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(send, "Share .mcpack with"));
                jsStatus("Choose Minecraft if it appears in the Android app chooser.", false);
            }
        } catch (ActivityNotFoundException noTarget) {
            jsStatus("No app accepted this pack. Try opening the original .mcpack from My Files.", true);
        }
    }

    private class CosmicBridge {
        @JavascriptInterface public void pickMcpack() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_TITLE, "Choose a Minecraft .mcpack file");
                startActivityForResult(intent, REQUEST_PICK_MCPACK);
            });
        }
        @JavascriptInterface public void getPacks() { runOnUiThread(MainActivity.this::sendPackList); }
        @JavascriptInterface public void openPack(String name) { runOnUiThread(() -> MainActivity.this.openPack(name)); }
        @JavascriptInterface public void deletePack(String name) {
            runOnUiThread(() -> {
                if (name == null || name.contains("/") || name.contains("\\")) return;
                File file = new File(packsDir, name);
                if (file.isFile() && file.delete()) jsStatus("Removed from Cosmic Client. Your original download was not deleted.", false);
                else jsStatus("Could not remove that pack.", true);
                sendPackList();
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_MCPACK) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) importPack(data.getData());
            else jsStatus("Import cancelled.", false);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
