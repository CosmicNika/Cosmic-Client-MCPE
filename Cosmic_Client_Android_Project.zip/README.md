# Cosmic Client Android wrapper project

This is an Android APK project for the Cosmic Client companion UI. It bundles the existing UI locally in an Android WebView. It is an installable Android app shell, but the UI remains HTML/CSS/JavaScript inside the native Android package.

## Build an APK using only your phone
1. Create a GitHub repository and upload all files/folders from this project ZIP (keep the `.github/workflows/build-apk.yml` path).
2. Open the repository's **Actions** tab and enable Actions if GitHub asks.
3. Choose **Build Cosmic Client APK**, tap **Run workflow**, then wait for the run to finish.
4. Open the successful workflow run, find **Artifacts**, and download `Cosmic-Client-debug-APK`.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`, then open it on your Samsung phone and allow installation from that source if Android asks.

The workflow builds a debug APK, not a Play Store release. Keep the APK private unless you understand the implications of sharing a debug build. For a release APK, configure signing and build a release variant.

## Limitations
- This app does not integrate with Minecraft. FPS remains a placeholder; CPS is the companion app tap test; Freecam/Zoom/ESP/visual toggles are demo/preferences only.
- No Donut SMP server connection is implemented.
- The project needs a cloud build run to produce the APK; this ZIP is source code, not the APK itself.
- The first Gradle build downloads Android build dependencies, so the cloud runner needs internet access.
