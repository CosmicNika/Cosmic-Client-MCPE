const $ = id => document.getElementById(id);
const defaults = {starGlow:65,opacity:82,aura:70,nightSky:false,outline:false,outlineStyle:"Soft glow",donutBadge:true,presetName:"Donut SMP",sessionNote:"",floatSize:58,floatOpacity:92,editMode:false,posX:84,posY:72,quickButtons:["HUD","Visual Lab","Donut SMP"]};
let state = {...defaults, ...(JSON.parse(localStorage.getItem("cosmicSettings")||"{}"))};
let taps = [], tapCount = 0, drag = null, toastTimer;
function save(){localStorage.setItem("cosmicSettings",JSON.stringify(state));applySettings()}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>$("toast").classList.remove("show"),1900)}
function applySettings(){
 document.documentElement.style.setProperty("--stars",state.starGlow/100);
 document.documentElement.style.setProperty("--aura",state.aura/100);
 document.documentElement.style.setProperty("--panel",`rgba(27,20,43,${state.opacity/100})`);
 ["starGlow","opacity","aura","floatSize","floatOpacity","posX","posY"].forEach(k=>{if($(k))$(k).value=state[k]});
 $("opacityLabel").value=state.opacity+"%";
 ["nightSky","outline","donutBadge","editMode"].forEach(k=>{if($(k))$(k).checked=!!state[k]});
 $("outlineStyle").value=state.outlineStyle;
 $("presetName").value=state.presetName;$("sessionNote").value=state.sessionNote;
 $("floatButton").style.width=state.floatSize+"px";$("floatButton").style.height=state.floatSize+"px";$("floatButton").style.opacity=state.floatOpacity/100;
 $("floatButton").style.left=state.posX+"%";$("floatButton").style.top=state.posY+"%";
 $("floatButton").classList.toggle("editing",state.editMode);
 $("editTop").style.color=state.editMode?"#e7c7ff":"";
}
function renderQuick(){
 const target=$("quickList");target.innerHTML="";
 state.quickButtons.forEach((name,i)=>{let b=document.createElement("button");b.className="quick-chip";b.innerHTML=`<span>✦ ${escapeHtml(name)}</span><span class="remove" aria-label="Remove">×</span>`;b.onclick=(e)=>{if(e.target.classList.contains("remove")){state.quickButtons.splice(i,1);save();renderQuick();renderFloatQuick()}else runQuick(name)};target.appendChild(b)});
 renderFloatQuick();
}
function renderFloatQuick(){const el=$("floatQuickList");el.innerHTML="";state.quickButtons.forEach(name=>{const b=document.createElement("button");b.className="float-quick";b.textContent="✦  "+name;b.onclick=()=>runQuick(name);el.appendChild(b)})}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function runQuick(name){$("quickMenu").classList.add("hidden");const map={"HUD":"hud","Visual Lab":"visual","Donut SMP":"donut","Settings":"settings","Mods":"mods"};if(map[name])showPage(map[name]);else toast(name+" is a companion shortcut demo.")}
function showPage(name){document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+name));document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.page===name));window.scrollTo({top:0,behavior:"smooth"})}
document.querySelectorAll(".tab").forEach(t=>t.addEventListener("click",()=>showPage(t.dataset.page)));
["starGlow","opacity","aura","floatSize","floatOpacity","posX","posY"].forEach(k=>$(k).addEventListener("input",e=>{state[k]=Number(e.target.value);save()}));
["nightSky","outline","donutBadge","editMode"].forEach(k=>$(k).addEventListener("change",e=>{state[k]=e.target.checked;save();if(k==="editMode")toast(state.editMode?"Edit mode on — drag the Cosmic button":"Edit mode off")}));$("outlineStyle").addEventListener("change",e=>{state.outlineStyle=e.target.value;save()});
$("addQuick").onclick=$("menuAdd").onclick=()=>{const name=prompt("Name your companion shortcut (e.g. Settings):");if(name&&name.trim()){if(state.quickButtons.length>=8){toast("Maximum 8 quick buttons");return}state.quickButtons.push(name.trim().slice(0,22));save();renderQuick();toast("Quick button added")}};
$("tapTest").addEventListener("click",()=>{const now=Date.now();taps.push(now);taps=taps.filter(t=>now-t<1000);tapCount++;$("cps").textContent=taps.length;$("tapResult").textContent=`${taps.length} tap(s) in the last second • ${tapCount} total test taps`;});
$("savePreset").onclick=()=>{state.presetName=$("presetName").value.trim()||"Donut SMP";state.sessionNote=$("sessionNote").value.trim();save();$("presetSaved").textContent="✦ Preset saved on this device.";toast("Donut SMP preset saved")};
document.querySelectorAll(".demo-action").forEach(b=>b.onclick=()=>toast(b.dataset.feature+" is a UI demo only — no Minecraft connection."));
$("floatButton").addEventListener("click",()=>{if(drag&&drag.moved){drag.moved=false;return}if(state.editMode){toast("Drag the button to reposition it");return}$("quickMenu").classList.toggle("hidden")});
$("closeMenu").onclick=()=>$("quickMenu").classList.add("hidden");
$("editTop").onclick=()=>{state.editMode=!state.editMode;save();toast(state.editMode?"Edit mode on — drag the Cosmic button":"Edit mode off")};
const fb=$("floatButton");
fb.addEventListener("pointerdown",e=>{if(!state.editMode)return;drag={x:e.clientX,y:e.clientY,left:fb.offsetLeft,top:fb.offsetTop,moved:false};fb.setPointerCapture(e.pointerId)});
fb.addEventListener("pointermove",e=>{if(!drag||!state.editMode)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.abs(dx)+Math.abs(dy)>4)drag.moved=true;const x=Math.max(28,Math.min(innerWidth-28,drag.left+dx)),y=Math.max(35,Math.min(innerHeight-35,drag.top+dy));fb.style.left=x+"px";fb.style.top=y+"px";fb.style.transform="translate(-50%,-50%)";state.posX=Math.round(x/innerWidth*100);state.posY=Math.round(y/innerHeight*100);$("posX").value=state.posX;$("posY").value=state.posY});
fb.addEventListener("pointerup",()=>{if(drag&&drag.moved)save();setTimeout(()=>drag=null,60)});
$("reset").onclick=()=>{if(confirm("Reset all Cosmic Client settings?")){state={...defaults};save();renderQuick();toast("Settings reset")}};
applySettings();renderQuick();
setTimeout(()=>$("loader").classList.add("done"),1550);
setInterval(()=>{$("fps").textContent="—";},1000);
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
